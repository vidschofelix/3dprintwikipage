% Matlab/FreeMat script to analyze 3d printer the heatbed geometry using an autolevel probe
% sen the Gcode "G29 T P10 V4" to scan your heatbed with the autolevel probe
% and copy the output into the file test1.txt
% enter "G29 T P10 V4" again and copy the output into test2.txt
% press F5 or click the green run button 
% the 10 in the command defined the number of points you can change it just for the 2 test it has to be identical

%by Lukas Skymuh 13-1-2017
% tested with Freemat 4.2, Printer A8, with Ramps 1.4, repetier host V1.6.2

probename='LJ18A3-8-Z/BX 12V diode option 3'

fileID = fopen('test1.txt','r');
% %20:24:56.644 : Bed X: 199.000 Y: 180.000 Z: 2.749

a=fgetline(fileID);
i=0;
while ~isempty(a)
    if ~isempty(findstr(a,'Bed X'))
        i=i+1;
        ids=find(a==' ');
        x(i)=str2num(a(ids(4):ids(5)));
        y(i)=str2num(a(ids(6):ids(7)));
        z(i)=str2num(a(ids(8):numel(a)));

     end
             a=fgetline(fileID);
end

figure(1)
p=sum(y==y(1));
x2=reshape(x,p,p)
x2(:,2:2:p)=x2(p:-1:1,2:2:p)
z2=reshape(z,p,p)
z2(:,2:2:p)=z2(p:-1:1,2:2:p)
y2=reshape(y,p,p)
surf(x2,y2,z2)
axis square
grid on
title([probename ' test 1']);
xlabel('x[mm]');
ylabel('y[mm]');
zlabel('z[mm]');
colorbar
%   [a,count]=fscanf(fileID, '%d:%d:%f:%s:%f Y: %f Z: %f\n')

%%
fileID = fopen('test2.txt','r');
% %20:24:56.644 : Bed X: 199.000 Y: 180.000 Z: 2.749

a=fgetline(fileID)
i=0;
while ~isempty(a)
    if ~isempty(findstr(a,'Bed X'))
        i=i+1;
        ids=find(a==' ');
        x(i)=str2num(a(ids(4):ids(5)));
        y(i)=str2num(a(ids(6):ids(7)));
        z(i)=str2num(a(ids(8):numel(a)));

     end
             a=fgetline(fileID)
end


figure(2)
p=sum(y==y(1));

x3=reshape(x,p,p)
x3(:,2:2:p)=x3(p:-1:1,2:2:p)

z3=reshape(z,p,p)
z3(:,2:2:p)=z3(p:-1:1,2:2:p)


y3=reshape(y,p,p)

surf(x3,y3,z3)
axis square
grid on
title([probename ' test 2']);
xlabel('x[mm]');
ylabel('y[mm]');
zlabel('z[mm]');
colorbar
grid on

%% remove the offset 
z2m=(z2-mean(z2(:)));
z3m=(z3-mean(z3(:)));

zref=(z2m+z3m)/2;

dz=z2-z3;

figure(3)
surf(x3,y3,dz)
axis square
grid on
title([probename ' test 2']);
xlabel('x[mm]');
ylabel('y[mm]');
zlabel('deviation between first and second measurement [mm]');
colorbar
grid on

deviations1=(z2m-zref);
deviations2=(z3m-zref);

devall=[deviations1(:); deviations2(:)]

figure(5)
hist(devall(:))
title([probename ' standard deviation ' num2str(std(devall(:))) 'mm'])
ylabel('number of datapoints')
xlabel('deviation to previous measurement[mm]')





